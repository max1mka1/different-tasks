import telebot


bot = telebot.TeleBot('926785754:AAGHakdtVQbcp5FTTcI7_jk-v_Z7yCBIxQU')


keyboard1 = telebot.types.ReplyKeyboardMarkup()
keyboard1.row('Привет', 'Пока')


@bot.message_handler(commands=['start'])
def start_message(message):
    bot.send_message(message.chat.id, 'Привет! id чата ' + str(message.chat.id))


@bot.message_handler(content_types=['text'])
def send_text(message):
    if message.text.lower() == 'привет':
        bot.send_message(message.chat.id, 'Привет, мой создатель')
    elif message.text == 'Пока':
        bot.send_message(message.chat.id, 'Прощай, создатель')


def main():
    while True:
        try:
          bot.polling(none_stop=True, interval=0)
        except:
          print('bolt')
          logging.error(f'error: {sys.exc_info()[0]}')
          time.sleep(5)

if __name__ == '__main__':
    main()