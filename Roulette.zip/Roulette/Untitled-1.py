from random import random as rdm, randint as rint, randrange as rndrg
from collections import namedtuple


Players = namedtuple('Car' , 'color mileage')

plr = Players()
print(r3fdf)

'''
class Players():
    '''
    Класс игроки,
    '''


    def __init__(count, players):
        self.count = count
        self.players = players



class Player:
    '''
    Класс игрок
    свойства:
    name - имя игрока
    autorate - уровень автоставки, и включена ли она
        0 - автоставка отключена
        > 1 - уровень автоставки
    rate - ставка игрока (руб)
    coeff - коэффициент, на котором игрок забирает выигрыш
    '''


    def __init__(name, rate, autorate, coeff):
        self.name = name
        self.rate = rate
        self.autorate = autorate
        self.coeff = coeff


    def make_rate(self):
        self.rate = rate





class Game():
    '''
    margin - маржа, или сумма бухгалтерской прибыли с каждой игры
    total_system_sum - общая заработанная системой сумма в текущую сессию
    (условно 10 игр - 1 сессия)
    total_players_sum - общая заработанная всеми игроками сумма за игру

    '''


    '''
    Функция инициализации margin, total_system_sum, total_players_sum)
    '''
    def __init__(self, margin, total_system_sum, total_players_sum):
        self.margin = margin
        self.total_system_sum = total_system_sum
        self.total_players_sum = total_players_sum


    '''
    Функция просчёта текущих сумм, рисков и выигранных игроками денег
    '''
    def calculate(self, rate):
        self.rate = rate






def summator():


def randomizer():



def main():
    players = []
    Players()
    for i in range(10):
        name = 'Player ' + str(i)
        rate =
        players.append(name)



if __name__ == '__main__':
    main()

'''
