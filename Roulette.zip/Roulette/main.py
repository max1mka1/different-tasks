from random import random, randint, randrange, triangular, choice, uniform
from collections import namedtuple
from time import sleep

'''
Название игры: "Заработайте, Крестьяне! Денег нет, НО! вы держитесь ... там ->> .!."
Условные обозначения:
Game                    - (игра) один запуск алгоритма для одной группы игроков
Session                 - одна сессия = 10 игр

_______________________________________________________________
+++ Словарь [Game] +++
margin                  - параметр, характеризующий жёсткость игры (минимальный процент выигрыша системы с игры)
tot_sys_sum             - общая заработанная системой сумма в текущую сессию
tot_pls_sum             - общая заработанная всеми игроками сумма за текущую сессию
risk_rate               - параметр, характеризующий риск системы проиграть.
                            Зависит от общей заработанной системой суммы в текущей сессии, 
                            скорости роста общей заработанной всеми игроками суммы за игру, 
                            а также некоторых скрытых факторов;
pre_rate_sum            - выигрыш системы в предыдущей игре
rate_sum                - текущая сумма ставок
autocoeff_x_rate_sum    - текущая сумма произведений автокоэффициентов (у кого выставлено) на ставку
pre_sys_sum             - выигрыш системы в предыдущей игре
system_sum              - выигрыш системы за всё время
players_sum             - сумма, выигранная игроками за всё время

_______________________________________________________________
+++ Именованный список игроки [Players] +++
number                  - количество игроков
dict                    - словарь, содержащий всех игроков
                            [ключ] - имя игрока
                            [значение] - именованный список Player конкретного
                            сгенерированного игрока с уникальными параметрами

_______________________________________________________________
+++ Именованный список игрок [Player] +++
свойства:
name - имя игрока
autocoeff               - уровень автоставки, и включена ли она
    0                   - автоставка отключена
    > 1                 - уровень автоставки
rate                    - ставка игрока (руб)
coeff                   - коэффициент, на котором игрок забирает выигрыш

_______________________________________________________________
'''
print(__doc__)


# Константные параметры игры
rate_step = 0.1             # шаг ставки
min_auto = 1                # минимальный уровень автоставки
max_auto = 5                # максимальный уровень автоставки
min_coeff = 1               # минимальный уровень коэффициента вывода средств
max_coeff = 90              # максимальный уровень коэффициента вывода средств
min_rate = 0                # минимальный уровень ставки, (р)
max_rate = 3000             # максимальный уровень ставки, (р)
min_N = 3                   # минимальное количество игроков
max_N = 30                  # максимальное количество игроков
game_N = 1                  # счётчик игр
session_N = 1               # счётчик сессий
total_system_sum = 0        # общая заработанная системой сумма в текущую сессию
total_players_sum = 0       # общая заработанная всеми игроками сумма за игру
FLAG = 0                    # FLAG = 0 - игра продолжается, 1 - конец игры
iron_gain = 15              # железный процент от игры
chance_to_fly = 5           # шанс коэффициенту взлететь до небес


Game = {'pre_rate_sum' : 0,                  # выигрыш системы в предыдущей игре
        'rate_sum' : 0,                      # текущая сумма ставок
        'autocoeff_x_rate_sum' : 0,          # текущая сумма произведений автокоэффициентов
                                             # (у кого выставлено) на ставку
        'sys_sum' : 0,                       # выигрыш системы в текущей игре
        'session_sys_sum' : 0,               # выигрыш системы в текущей сессии
        'system_sum' : 0,                    # выигрыш системы за всё время
        't_players_sum' : 0,                 # сумма, выигранная игроками в текущей игре
        'players_sum' : 0,                   # сумма, выигранная игроками за всё время
}



Players = namedtuple('Players_info',
                     'number, '                     # Общее количество игроков
                     'dict')                        # словарь игроков - содержит в себе имена игроков класса Player


Player = namedtuple('Player_info',
                    'name '                         # имя игрока
                    'rate '                         # ставка игрока (руб)
                    'autocoeff '                    # уровень автоставки, и включена ли она
                    'coeff')                        # коэффициент, на котором игрок забирает выигрыш


def pre_calculate_game(Game, players, win_coeff):
    '''
    Функция расчета параметров игры ДО! старта игры (autocoeff_x_rate_sum, rate_sum)
    '''
    auto_x_rate_sum = 0
    rate_sum = 0
    if win_coeff != 0:
        for i in range(1, players.number + 1):
            name = 'Player_' + str(i)
            rate_sum += players.dict[name].rate
            if players.dict[name].autocoeff > 0:
                auto_x_rate_sum += players.dict[name].autocoeff * players.dict[name].rate
    Game['rate_sum'] = rate_sum
    Game['autocoeff_x_rate_sum'] = auto_x_rate_sum
    print(f'''Текущая сумма ставок всех игроков = {Game['rate_sum']}''')


def re_calculate_game(Game, players, win_coeff, t_coeff):
    '''
    Функция перерасчета параметров игры по мере роста коэффициента пузыря,
    просчёта текущих сумм, рисков и выигрыша игроков
    t_coeff             - текущий коэффициент (по мере роста коэффициента пузыря)
    t_sum               - текущая выигранная игроками сумма по ходу игры
    session_sys_sum     - сумма всех заработанных системой денег в текущей сессии
    '''
    t_sum = 0
    for i in range(1, players.number + 1):
        name = 'Player_' + str(i)
        rate = players.dict[name].rate
        autocoeff = players.dict[name].autocoeff
        coeff = players.dict[name].coeff
        if autocoeff <= t_coeff:
            t_sum += rate * autocoeff
        elif coeff <= t_coeff:
            t_sum += rate * coeff
    Game['t_players_sum'] = t_sum
    # Если сумма всех ставок игроков превышает сумму за вычетом железного банка,
    # то с вероятностью (chance_to_fly / 100) [85% если chance_to_fly = 15%] мы
    # НЕ! завершаем текущую игру, НО! только при условии, что выигранные системой
    # деньги в текущей сессии есть, и сумма всех ставок игроков * текущий коэффициент < 0.5
    # от session_sys_sum, чем текущие заработки крестьян :)
    print(f'Текущий коэффициент = {t_coeff}')
    print(f'''Текущя заработанная игроками сумма = {Game['t_players_sum']}''')
    FLAG = 0
    if (Game['t_players_sum'] >= (Game['rate_sum'] * (1 - iron_gain) / 100)) and (t_coeff < win_coeff) and ((0.5 * Game['session_sys_sum']) > t_sum):
        pass # FLAG = 0    # продолжаем полёт
    else:
        t_coeff = 0
        FLAG = 1    # обрыв игры
        Game['t_players_sum'] = t_sum
        Game['sys_sum'] =  round((t_sum - Game['rate_sum']), 2)
        print(f'''!! Выигранная системой сумма в текущей игре = {Game['sys_sum']} !!''')
    return FLAG, t_coeff


def after_calculate_game(Game, players, win_coeff, t_coeff):
    '''
    Функция расчета параметров игры ПОСЛЕ! окончания игры
    '''
    print('+++++++++++++++++++++++++++++++++++++++++++++++++++')
    Game['t_players_sum'] = Game['sys_sum']
    Game['sys_sum'] = Game['t_players_sum'] - Game['rate_sum']
    Game['session_sys_sum'] += Game['sys_sum']
    Game['autocoeff_x_rate_sum'] = 0
    Game['t_players_sum'] = 0
    Game['rate_sum'] = 0
    Game['pre_rate_sum'] = Game['sys_sum']
    Game['system_sum'] += Game['sys_sum']
    print(f'''Общая заработанная системой сумма = {Game['system_sum']}''')
    print('+++++++++++++++++++++++++++++++++++++++++++++++++++')


def start_game(players, game_N):
    '''
    Функция предрасчета выигрышного коэффициента
    '''
    win_coeff = choice(tuple(0 for x in range(100)) +
                        tuple(round((randint(min_coeff, max_coeff) +
                                     random()), 2) for x in range(1000)))
    print(f'Выигрышный коэффициет в сессии {session_N} игры {game_N} = {win_coeff}')
    return win_coeff


def print_players(players):
    # Функция вывода в консоль информации по сгенерированным игрокам
    N = players.number
    print(f'Общее количество игроков = {N}')
    print('-----------------------------------------------')
    for i in range(1, N + 1):
        name = 'Player_' + str(i)
        rate = players.dict[name].rate
        autocoeff = players.dict[name].autocoeff
        coeff = players.dict[name].coeff
        print(f'Игрок {name}, '
              f'cтавка {rate}, '
              f'автоставка {autocoeff}, '
              f'коэффициент {coeff} ;')
    print('-----------------------------------------------')


def generate_players():
    # Функция генерации игроков
    dict = {}
    N = randint(min_N, max_N)
    poss_autorates = list(round((randint(min_auto, max_auto) + random()), 1) for x in range(1000))
    poss_rates = tuple(round((randint(min_rate, max_rate) + random()), 2) for x in range(1000))
    poss_coeffs = tuple(round((randint(min_coeff, max_coeff) + random()), 1) for x in range(1000))
    for i in range(1, N + 1):
        name = 'Player_' + str(i)
        rate = choice(poss_rates)
        autocoeff = choice(poss_autorates)
        coeff = choice(poss_coeffs)
        dict[name] = Player(name, rate, autocoeff, coeff)
    players = Players(N, dict)
    print_players(players)
    return players


def main(session_N, game_N, FLAG):
    while True:
        print(f'Сессия № {session_N}, игра № {game_N.')
        for i in range(10):
            for i in range(5, -1, -1):
                print(i)
                sleep(1)        # отсчёт времени 5 ... 0
            players = generate_players()
            win_coeff = start_game(players, game_N)
            pre_calculate_game(Game, players, win_coeff)
            t_coeff = 0.0
            t_coeff = 1
            while FLAG != 1:
                FLAG, t_coeff = re_calculate_game(Game, players, win_coeff, t_coeff)
                t_coeff = (t_coeff + 0.1)
            after_calculate_game(Game, players, win_coeff, t_coeff)
            FLAG = 0
            game_N += 1
        session_N += 1
        game_N = 0
        Game['session_sys_sum'] = 0    # сбрасываем сумму выигрыша за последнюю сессию
        print(f'')


if __name__ == '__main__':
    main(session_N, game_N, FLAG)
