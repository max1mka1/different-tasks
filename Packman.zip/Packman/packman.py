import time
from pygame import *
from random import *
import pygame

#класс-родитель для других спрайтов
class GameSprite(sprite.Sprite):
  #конструктор класса
  def __init__(self, player_image, player_x, player_y, player_speed):
      self.ghost = 0
      # Вызываем конструктор класса (Sprite):
      sprite.Sprite.__init__(self)
      # каждый спрайт должен хранить свойство image - изображение
      self.image = transform.scale(image.load(player_image), (80, 80))
      self.speed = player_speed
      # каждый спрайт должен хранить свойство rect - прямоугольник, в который он вписан
      self.rect = self.image.get_rect()
      self.rect.x = player_x
      self.rect.y = player_y
   #метод, отрисовывающий героя на окне
  def reset(self):
      window.blit(self.image, (self.rect.x, self.rect.y))

#класс главного игрока
class Player(GameSprite):
  #метод, в котором реализовано управление спрайтом по кнопкам стрелочкам клавиатуры
  def update(self):
      keys = key.get_pressed()
      if keys[K_LEFT] and self.rect.x > 0:
          self.rect.x -= self.speed
      if keys[K_RIGHT] and self.rect.x < win_width:
          self.rect.x += self.speed
      if keys[K_UP] and self.rect.y > 0:
          self.rect.y -= self.speed
      if keys[K_DOWN] and self.rect.y < win_height:
          self.rect.y += self.speed

#класс спрайта-врага
class Enemy(GameSprite):
  side = "left"
   #движение врага
  def update(self):
      keys = key.get_pressed()
      skin_1 = 'cyborg.png'
      skin_10 = 'pac-10.png'
      if keys[K_w]:
          monster.image = transform.scale(image.load(skin_10), (60, 60))
      else:
          monster.image = transform.scale(image.load(skin_1), (60, 60))
      if self.rect.x <= 410:
          self.side = "right"
      if self.rect.x >= win_width - 85:
          self.side = "left"
      if self.side == "left":
          self.rect.x -= self.speed
      else:
          self.rect.x += self.speed
#класс элемента стены
class Wall(sprite.Sprite):
    ''' Конструктор класса - или функция инициализации'''
    # color - цвет RGB, wall_x, y - координаты X Y расположения стены в окне
    #  wall_width, height - ширина и высота стены
    def __init__(self, color_1, color_2, color_3, wall_x, wall_y, wall_width, wall_height):
       sprite.Sprite.__init__(self)
       # Задаём свойства экземпляра класса
       self.color_1 = color_1
       self.color_2 = color_2
       self.color_3 = color_3
       self.width = wall_width
       self.height = wall_height
       # картинка стены - прямоугольник нужных размеров и цвета
       # Создаём прямоугольник
       self.image = Surface([self.width, self.height])
       # Задаём цвет прямоугольника
       self.image.fill((color_1, color_2, color_3))
       # каждый спрайт должен хранить свойство rect - прямоугольник
       self.rect = self.image.get_rect()
       # Задаём координаты X Y прямоугольника
       self.rect.x = wall_x
       self.rect.y = wall_y
    def draw_wall(self):
      draw.rect(window, (self.color_1, self.color_2, self.color_3), (self.rect.x, self.rect.y, self.width, self.height))

win_width = 800
win_height = 600
display.set_caption("Лабиринт")
window = display.set_mode((win_width, win_height))
# Создаём стены
    # color - цвет RGB, wall_x, y - координаты X Y расположения стены в окне
    #  wall_width, height - ширина и высота стены
#color_1, color_2, color_3, wall_x, wall_y, wall_width, wall_height):
# имя_стены = Wall(цвет1, цвет2, цвет3, коорд X, коорд Y, длина, ширина)
w1 = Wall(0, 0, 0, win_width / 2 - win_width / 3, win_height / 2, 300, 10)
w2 = Wall(0, 0, 0, 410, win_height / 2 - win_height / 4, 10, 350)
w3 = Wall(0, 0, 0, 280, 410, 10, 350)
w4 = Wall(0, 0, 0, 80, 400, 200, 10)
#создаем спрайты
packman = Player('1-2.png', 5, win_height - 80, 10)
monster = Enemy('cyborg.png', win_width - 80, 200, 10)
monster2 = Enemy('pac-8.png', randint(5, win_width-5), randint(5, win_height-5), 8)
final_sprite = GameSprite('pac-1.png', win_width - 85, win_height - 100, 0)
strawberry = GameSprite('strawberry.png', 50, 50, 0)
wall_1 = GameSprite('wall_1.png', 100, 100, 0)
wall_2 = GameSprite('wall_1.png', 150, 250, 0)
wall_3 = GameSprite('wall_1.png', 300, 200, 0)
background = image.load("background.png")
background = transform.scale(background, (win_width, win_height))
window.blit(background,(0,0))
#переменная, отвечающая за то, как кончилась игра
finish = False
#игровой цикл
run = True
clock = pygame.time.Clock()
start_time = pygame.time.get_ticks()
while run:
  #цикл срабатывает каждую 0.05 секунд
  pygame.time.delay(5)
   #перебираем все события, которые могли произойти
  for e in event.get():
      #событие нажатия на кнопку “закрыть”
      if e.type == QUIT:
          run = False

#проверка, что игра еще не завершена
  if not finish:
      #обновляем фон каждую итерацию
      # window.fill((255, 255, 255))
       #рисуем стены
      window.blit(background,(0,0))
      w1.draw_wall()
      w2.draw_wall()
      w3.draw_wall()
      w4.draw_wall()
      # запускаем движения спрайтов
      packman.update()
      monster.update()
      monster2.update()
      # обновляем их в новом местоположении при каждой итерации цикла
      packman.reset()
      monster.reset()
      monster2.reset()
      strawberry.reset()
      wall_1.reset()
      wall_2.reset()
      wall_3.reset()
      final_sprite.reset()
      current_time = pygame.time.get_ticks()
      seconds = round(current_time - start_time)
      if seconds % 6 == 5:
          monster2.rect.x = randint(5, win_width-80)
          monster2.rect.y = randint(5, win_height-80)

      if sprite.collide_rect(packman, strawberry):
          strawberry.rect.x = randint(5, win_width-80)
          strawberry.rect.y = randint(5, win_height-80)
          packman.image = transform.scale(image.load('pac-5.png'), (60, 60))
          packman.speed = 15

      #Проверка столкновения героя с врагом и стенами
      if packman.ghost == 0:
          if sprite.collide_rect(packman, monster) or sprite.collide_rect(packman, w1) or sprite.collide_rect(packman, w2)or sprite.collide_rect(packman, w3)or sprite.collide_rect(packman, w4):
              finish = True
              #вычисляем отношение
              img = image.load('game-over_1.png')
              d = img.get_width() // img.get_height()
              window.fill((255, 255, 255))
              window.blit(transform.scale(img, (win_height * d, win_height)), (90, 0))

      if sprite.collide_rect(packman, final_sprite):
          finish = True
          img = image.load('thumb.jpg')
          window.fill((255, 255, 255))
          window.blit(transform.scale(img, (win_width, win_height)), (0, 0))

      if sprite.collide_rect(packman, wall_1) or sprite.collide_rect(packman, wall_2) or sprite.collide_rect(packman, wall_3):
          packman.image = transform.scale(image.load('pac-2.png'), (80, 80))
          packman.ghost = 1

  display.update()
