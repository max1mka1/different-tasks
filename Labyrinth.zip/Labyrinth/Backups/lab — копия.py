import random
import pygame
import sys


def main_menu_window():
    window = pygame.display.set_mode((800, 600))
    pygame.display.set_caption('Archer')
    screen = pygame.Surface((800, 640))
    info = pygame.Surface((800, 30))


def line(x, y, zCount, point):
    '''
    Функция line создаёт 1 ответвление от лабиринта за вызов.
    Ответвление генерируется начиная со случайного незанятого места и заканчивается когда соеденится с уже сгенерированной 
    частью лабиринта(при первом вызове это только клетка start)

    на вход подаётся:
    x,y - размер лабиринта по x и по y
    zCount - кол-во не занятых клеток
    point - текущая позиция(начальная)
    '''
    sym = 2
    nSym = 3
    road = [0, 1]
    block = 4
    ink = 5
    flag = True
    map[point[0]][point[1]] = ink
    while flag:
        pWays = []
        for i in ways:
            if map[point[0] + i[0]][point[1] + i[1]] == sym:
                flag = False
                pWays = [i, ]
                break
            if map[point[0]+i[0]][point[1]+i[1]] in road and choose(x, y, point, [i[0], i[1]], sym, road, nSym):
                pWays.append(i)
        r = random.randint(0, pWays.__len__()-1)
        zCount = step(point, pWays[r], zCount, block, ink)
        point = [point[0]+pWays[r][0], point[1]+pWays[r][1]]
    for i in range(x):
        for j in range(y):
            if map[i][j] == 4:
                map[i][j] = 1
            if map[i][j] == 5:
                map[i][j] = 2
    return zCount


def gen(x, y):
    '''
    генерирует пустое поле для лабиринта размером x на y
    '''
    nMap = [0] * x
    j = 0
    for i in nMap:
        nMap[j] = [0] * y
        j += 1
    return nMap


def step(point, way, zCount, block, ink):
    '''
    удлиняет ответвление на 1 клетку.
    point - текущая позиция. [x,y]
    way - направление шага. [0,-1/1]/[-1/1,0](влево/вправо/вверх/вниз)
    zCount - кол-во незанятого места
    block - обозначение для клетки новой стенки в массиве
    ink - обозначение для клетки новой дороги в массиве
    '''

    for i in ways, angles:
        for j in i:
            if map[point[0]+j[0]][point[1]+j[1]] == 0 and ((way[0] and way[0] != j[0]) or (way[1] and way[1] != j[1])):
                map[point[0] + j[0]][point[1] + j[1]] = block
                zCount -= 1
    if map[point[0] + way[0]][point[1] + way[1]] == 0:
        zCount -= 1
    map[point[0]+way[0]][point[1]+way[1]] = ink
    return zCount


def choose(x, y, point, way, sym, road, nSym):
    '''
    проверяет есть ли путь у ветки до лабиринта
    x,y - размер лабиринта по x и по y
    point - текущая позиция. [x,y]
    way - направление шага. [0,-1/1]/[-1/1,0](влево/вправо/вверх/вниз)
    sym - обозначение для клетки старой дороги в массиве
    nSym - обозначение для клетки новой дороги в массиве
    road - клетки через которые можно проводить новое ответвление.
    0 - незанятые, 1 - старая стенка(для присоединения к остальному лабиринту)
    '''
    tPoint = [point[0]+way[0], point[1]+way[1]]
    nMap = gen(x, y)
    for i in ways, angles:
        for j in i:
            if (way[0] and way[0] != j[0]) or (way[1] and way[1] != j[1]):
                nMap[point[0] + j[0]][point[1] + j[1]] = nSym
    nMap[tPoint[0]][tPoint[1]] = nSym
    potent = [tPoint]
    flag = False
    for i in potent:
        if flag:
            break
        for j in ways:
            if map[i[0]+j[0]][i[1]+j[1]] == sym:
                flag = True
                break
            if nMap[i[0]+j[0]][i[1]+j[1]] == 0 and map[i[0]+j[0]][i[1]+j[1]] in road:
                nMap[i[0]+j[0]][i[1]+j[1]] = nSym
                potent.append([i[0]+j[0], i[1]+j[1]])

    return flag



main_menu_window()
x = int(input("введите длину "))
y = int(input("введите ширину "))
start = [random.randint(1, x - 2), 1]
zCount = (x-2)*(y-2)-2
plain = zCount
finish = [random.randint(1, x - 2), y - 2]
print(finish)
map = gen(x, y)
for i in range(x):
    for j in range(y):
        if i == x-1 or i == 0 or j == y-1 or j == 0:
            map[i][j] = 9

# соответствует 4 направлениям вокруг клетки при прибавлении к координатам(const)
ways = [[0, 1], [1, 0], [0, -1], [-1, 0]]
# дополнение к ways. соответствует 4 углам вокруг клетки при прибавлении к координатам
angles = [[1, 1], [1, -1], [-1, 1], [-1, -1]]
map[start[0]][start[1]] = 2
while zCount > 0:
    print((str)((int)((plain-zCount)/plain*100))+'%')
    flag = False
    r = random.randint(0, zCount-1)
    for i in range(x):
        for j in range(y):
            if map[i][j] == 0:
                if r:
                    r -= 1
                else:
                    zCount -= 1
                    zCount = line(x, y, zCount, [i, j])
                    flag = True
                    break
        if flag:
            break
    if not flag:
        print('/', zCount)
        break
line(x, y, zCount, finish)
map[start[0]][0] = 2
map[finish[0]][y-1] = 2

for i in range(x):
    for j in range(y):
        if i == finish[0] and j == finish[1]:
            print('f', end='')
        elif i == start[0] and j == start[1]:
            print('s', end='')
        elif map[i][j] == 2:
            print('*', end='')
        else:
            print(' ', end='')
    print()

