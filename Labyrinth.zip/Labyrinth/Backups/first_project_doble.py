'''
Назначение:
Подссчитыавет очки игрока за игру, прибовляет их
к текущим(если это не 1уровень) и сохраняет их в файл.

Входные данные:
Размер карты x * y
Время игры
Имя игрока

Результат:
Нет

'''
pointplayer = 0
newpointplayers = 0
line = 0                                     #номер строки с нужным очками
points = 1000                                 #очки, полученные игроком
player = input('введите ник: ')               #никнейм игрока, которому нужно прибавить очков
with open("test.txt", 'r+') as f:                   #здесь ищем в файле очки игрока, чей ник нам известен
    for string in f:
        if player in string:
            words = string.split()
            pointplayer = int(words[1]) # ind + 1
            line += 1
            newpointplayers = pointplayer + points
            # text = str(line).replace(str(pointplayer), str(newpointplayers))
            words[1] = newpointplayers
            f.write(str(words[0]) + ' ' + str(words[1]))
            break

'''
with open("test.txt", "w") as file_out:
    file_out.write(text)
'''
'''
with open('test.txt') as file_in:
    text = file_in.read()
text = text.replace(str(pointplayer), str(newpointplayers))
with open("test2", "w") as file_out:
    file_out.write(text)
'''