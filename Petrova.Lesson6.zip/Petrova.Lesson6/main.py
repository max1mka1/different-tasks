#Это задание продолжает практическое задание прошлого урока. За основу возьмите свой код с классами Word и Sentence.
# Выполним с ним следующие преобразования:
#1. Создайте новые классы Noun (существительное) и Verb (глагол).
#2. Настройте наследование новых классов от класса Word.
#3. Добавьте в новые классы свойство grammar («Грамматические характеристики»).
# Для класса Noun укажите значение по умолчанию «сущ» (сокращение от существительное),
# а для Verb — «гл» (сокращение от глагол). Вспомните про инкапсуляцию и сделайте свойство grammar защищённым.
#4. Исправьте класс Word, чтобы указанный ниже код не вызывал ошибки.
#Подсказка: теперь в нём не нужно хранить части речи.
#words = []
#words.append(Noun("собака"))
#words.append(Verb("ела"))
#words.append(Noun("колбасу"))
#words.append(Noun("кот"))
#По желанию добавьте ещё несколько глаголов и существительных.
#5. Протестируйте работу старого метода show класса Sentence. Если предложения не формируются, исправьте ошибки.
#6. Допишите в классы Noun и Verb метод part. Данный метод должен возвращать строку с полным названием части речи.
#7. Протестируйте работу метода show_part класса Sentence. Исправьте ошибки, чтобы метод работал.
#Подсказка: ранее part был свойством класса Word, а теперь это метод классов Noun и Verb.


class Word:
    text = ""
    def __init__(self, text):
        self.text = text

    def __str__(self):
        return self.text

class Noun(Word):
    _grammar = "сущ"

    def part(self):
        self.part = "существительное"
        return self.part


class Verb(Word):
    _grammar = "гл"

    def part(self):
        self.part = "глагол"
        return self.part

class Adverb(Word):
    _grammar = "нар"

    def part(self):
        self.part = "наречие"
        return self.part

class Sentence:
    content = []
    part = ""
    word = ""

    def show(self, content):
        word_list = []
        for i in content:
            word = words[i]
            word_list.append(word)
        for i in word_list: print(i, end=" ")


    def show_parts(self, content):
        part_list = []
        for i in content:
            part = words[i].part()
            if part in part_list:
                pass
            else: part_list.append(part)
        print(part_list)

words = []
words.append(Noun("собака"))
words.append(Verb("ела"))
words.append(Noun("колбасу"))
words.append(Noun("кот"))
words.append(Adverb("вечером"))


sentence1 = Sentence()
sentence1.show([0,1,2,4])
print("\n")
sentence1.show_parts([0,1,2,4])


