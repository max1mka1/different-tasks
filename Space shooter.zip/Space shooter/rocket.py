import time
from pygame import *
from random import *
import pygame

class GameSprite(sprite.Sprite):    #класс-родитель для других спрайтов
  def __init__(self, player_image, player_x, player_y, player_speed):   #конструктор класса
      self.ghost = 0
      sprite.Sprite.__init__(self)  # Вызываем конструктор класса (Sprite):
      # каждый спрайт должен хранить свойство image - изображение
      self.image = transform.scale(image.load(player_image), (80, 80))
      self.speed = player_speed
      # каждый спрайт должен хранить свойство rect - прямоугольник, в который он вписан
      self.rect = self.image.get_rect()
      self.rect.x = player_x
      self.rect.y = player_y
   #метод, отрисовывающий героя на окне
  def reset(self):
      window.blit(self.image, (self.rect.x, self.rect.y))

#класс главного игрока
class Player(GameSprite):
  #метод, в котором реализовано управление спрайтом по кнопкам стрелочкам клавиатуры

  def update(self):
      keys = key.get_pressed()
      if keys[K_LEFT] and self.rect.x > 0:
          self.rect.x -= self.speed
      if keys[K_RIGHT] and self.rect.x < win_width:
          self.rect.x += self.speed
      if keys[K_UP] and self.rect.y > 0:
          self.rect.y -= self.speed
      if keys[K_DOWN] and self.rect.y < win_height:
          self.rect.y += self.speed



#класс спрайта-врага
class Enemy(GameSprite):
  side = "left"
   #движение врага
  def update(self):
      keys = key.get_pressed()
      if self.rect.x <= 410:
          self.side = "right"
      if self.rect.x >= win_width - 85:
          self.side = "left"
      if self.side == "left":
          self.rect.x -= self.speed
      else:
          self.rect.x += self.speed

win_width = 800
win_height = 600
display.set_caption("SpaceShooter")
window = display.set_mode((win_width, win_height))
monsters = sprite.Group()       # создание группы спрайтов-врагов
for i in range(1, 6):
    monster = Enemy ('ufo_4.png',randint(5,win_width-5), 0, 10) # создание экземпляра класса врага
    monsters.add(monster)       # cозданного врага в группу монстров
bullets = sprite.Group()       # создание группы спрайтов-врагов
for i in range(1, 6):
    bullet = Enemy('bullet.png',randint(5,win_width-5), win_height - 30, 10) # создание экземпляра класса врага
    bullets.add(bullet)       # cозданного врага в группу монстров
rocket = Player('rocket.png', win_width//2, win_height - 80, 10)
background = image.load("galaxy_1.jpg")
background = transform.scale(background, (win_width, win_height))
monsters.update()
monsters.draw(window)
window.blit(background,(0,0))
score = 0
font.init()     # подгружаем отдельно функции для работы со шрифтом
font = font.Font(None, 36)      # во время игры пишем надписи размером 36
text = font.render("Счет: " + str(score), 1, (255, 255, 255))   # пишем текст на экране
window.blit(text, (10, 20))     # отображаем текст в нужном месте
finish = False                  #переменная, отвечающая за то, как кончилась игра
run = True                      #игровой цикл
while run:
  pygame.time.delay(50)     #цикл срабатывает каждую 0.05 секунд
  for e in event.get():#перебираем все события, которые могли произойти
      if e.type == QUIT:#событие нажатия на кнопку “закрыть”
          run = False
  if not finish:# проверка, что игра еще не завершена
      window.blit(background,(0,0)) #обновляем фон каждую итерацию
      monsters.update()
      monsters.draw(window)
      monster.reset()
      rocket.update()
      rocket.reset()
      bullets.update()
      bullets.draw(window)
      collides = sprite.groupcollide(monsters, bullets, True, True)  # проверка столкновения пули и монстра (монстр и пуля при касании исчезают)
      for c in collides: # этот цикл повторится столько раз, сколько монстров подбито
          monster = Enemy('ufo_4.png', randint(5,win_width-5), 0, 10)      # создаём нового врага взамен убитого, чтобы враги не кончились
          monsters.add(monster)
      '''
      w1.draw_wall()
      w2.draw_wall()
      w3.draw_wall()
      w4.draw_wall()
      # запускаем движения спрайтов
      packman.update()
      monster.update()
      monster2.update()
      # обновляем их в новом местоположении при каждой итерации цикла
      packman.reset()
      monster.reset()
      monster2.reset()
      strawberry.reset()
      wall_1.reset()
      wall_2.reset()
      wall_3.reset()
      final_sprite.reset()
      current_time = pygame.time.get_ticks()
      seconds = round(current_time - start_time)
      if seconds % 6 == 5:
          monster2.rect.x = randint(5, win_width-80)
          monster2.rect.y = randint(5, win_height-80)

      if sprite.collide_rect(packman, strawberry):
          strawberry.rect.x = randint(5, win_width-80)
          strawberry.rect.y = randint(5, win_height-80)
          packman.image = transform.scale(image.load('pac-5.png'), (60, 60))
          packman.speed = 15

      #Проверка столкновения героя с врагом и стенами
      if packman.ghost == 0:
          if sprite.collide_rect(packman, monster) or sprite.collide_rect(packman, w1) or sprite.collide_rect(packman, w2)or sprite.collide_rect(packman, w3)or sprite.collide_rect(packman, w4):
              finish = True
              #вычисляем отношение
              img = image.load('game-over_1.png')
              d = img.get_width() // img.get_height()
              window.fill((255, 255, 255))
              window.blit(transform.scale(img, (win_height * d, win_height)), (90, 0))

      if sprite.collide_rect(packman, final_sprite):
          finish = True
          img = image.load('thumb.jpg')
          window.fill((255, 255, 255))
          window.blit(transform.scale(img, (win_width, win_height)), (0, 0))

      if sprite.collide_rect(packman, wall_1) or sprite.collide_rect(packman, wall_2) or sprite.collide_rect(packman, wall_3):
          packman.image = transform.scale(image.load('pac-2.png'), (80, 80))
          packman.ghost = 1
      '''
  display.update()
